import streamlit as st
import helper
import json
import pandas as pd

st.set_page_config(page_title="Course Plan Generator", layout="wide")
st.title("📘 Course Plan Generator")

student_id = '201801657'  # Assume logged in
student_major = helper.get_major(student_id)
is_new_student = not helper.get_completed_courses(student_id)


def safe_priority(priority):
            try:
                return float(priority)
            except (ValueError, TypeError):
                return 0.0
            
method = st.radio(
    "Select Generation Method:",
    ["Knowledge Graph Only", "Knowledge Graph + ML"],
    horizontal=True
)

courses_list =helper.get_all_courses_for_major(student_major)
completed_courses = helper.get_completed_courses(student_id)
completed_courses_details = [
        {
            'Course Code': course_id,
            'Course Name': helper.get_course_details(course_id, courses_list)['name'],
             'Credit Hours': helper.get_course_details(course_id, courses_list)['credit_hours']
            }
            for course_id in completed_courses
        ]

prompt = helper.prepare_prompt_second_approach(student_id, student_major, is_new_student)

# Initialize total hours
total_hours = sum(course['Credit Hours'] for course in completed_courses_details)

if method == "Knowledge Graph Only":
    max_credit_hours = st.number_input("Max Credit Hours per Semester:", min_value=1, max_value=21, value=16)
        
    if st.button("Generate KG Plan"):
        courses_list = helper.get_all_courses_for_major(student_major)
        plan = helper.generate_plan(student_id, max_credit_hours, 'fall', courses_list)

        st.subheader("Generated Plan (KG Only)")
        
                # Define the number of columns
        num_columns = 3

        # Split the terms into chunks of 3 (rows)
        rows = [plan[i:i + num_columns] for i in range(0, len(plan), num_columns)]

        # Iterate through the rows
        for row in rows:
            # Create columns for the row
            cols = st.columns(num_columns)
            
            # Iterate through terms and corresponding columns
            for col, term in zip(cols, row):
                semester = term['semester']
                courses = term['courses']

                with col:
                   # Display a smaller subheader
                    st.markdown(f"<h2>{semester}</h2>", unsafe_allow_html=True)

                    
                    # Create a list to store course data for the table
                    course_data = []
                    term_hours = 0 

                    for course_id in courses:
                        course_details = helper.get_course_details(course_id, courses_list)
                        course_data.append({
                            'Score': f"{round(safe_priority(course_details['priority']), 2):.2f}" , # Format with 2 decimal places
                            'Name': f"{course_id} - {course_details['name']}",
                            'Hrs': course_details['credit_hours']
                        })
                        term_hours += course_details['credit_hours']
                    
                    # Convert to DataFrame
                    course_df = pd.DataFrame(course_data)
                    
                    # Set the index on the original DataFrame
                    course_df = course_df.set_index(course_df.columns[0])

                    # Display all courses in one table
                    st.dataframe(course_df, use_container_width=True)

                    # Display term credit hours
                    st.write(f'**Term Credit Hours:** {term_hours}')
                    total_hours += term_hours

                

        # Display total credit hours
        st.write(f'**Total Credit Hours:** {total_hours}')
        

elif method == "Knowledge Graph + ML":
    preferences = st.text_area("Preferences (Optional)")
    if st.button("Generate Hybrid Plan"):
        if preferences:
            prompt += f"\nAdditional preferences: {preferences}"
        
        response = helper.generate_plan_second_approach(prompt)

        try:
            plan_dict = json.loads(response.strip().replace("```json", "").replace("```", ""))
        except:
            st.error("Failed to parse generated plan.")
            st.text(response)
            st.stop()

        st.subheader("Generated Plan (KG + ML)")
                # Define the number of columns
        num_columns = 3

        # Split the terms into chunks of 3 (rows)
        terms = list(plan_dict.items())
        rows = [terms[i:i + num_columns] for i in range(0, len(terms), num_columns)]

        # Iterate through the rows
        for row in rows:
            # Create columns for the row
            cols = st.columns(num_columns)
            
            # Iterate through terms and corresponding columns
            for col, (semester, courses) in zip(cols, row):
                with col:
                    # Display a smaller subheader
                    st.markdown(f"<h2>{semester}</h2>", unsafe_allow_html=True)
                    
                    # Create a list to store course data for the table
                    course_data = []
                    term_hours = 0

                    for index, course in enumerate(courses, start=1):
                        course_data.append({
                            "Index": index,
                            "Name": f"{course['id']} - {course['name']}",
                            "Hrs": course['credit_hours']
                        })
                        term_hours += course['credit_hours']

                    # Convert to DataFrame
                    course_df = pd.DataFrame(course_data)
                    
                    # Set the index on the original DataFrame
                    course_df = course_df.set_index(course_df.columns[0])

                    # Display all courses in one table
                    st.dataframe(course_df, use_container_width=True)

                    # Display term credit hours
                    st.write(f'**Term Credit Hours:** {term_hours}')
                    total_hours += term_hours

        # Display total credit hours
        st.write(f'**Total Credit Hours:** {total_hours}')
